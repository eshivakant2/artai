﻿using Microsoft.SemanticKernel;
using Microsoft.KernelMemory;
using System.ComponentModel;

public class KernelMemoryServicePlugin
{
    private readonly IKernelMemory _memoryClient;
    public KernelMemoryServicePlugin(IKernelMemory memoryClient)
    {
        _memoryClient = memoryClient;
    }

    [KernelFunction("Search")]
    [Description("Search for information in the knowledge base")]
    public async Task<string> SearchAsync(
        [Description("The search query")] string query,
        [Description("Maximum number of results to return")] int limit = 5,
        [Description("Minimum relevance score (0.0 to 1.0)")] double minRelevance = 0.0)
    {
        try
        {
            var results = await _memoryClient.SearchAsync(query, limit: limit, minRelevance: minRelevance);

            if (!results.Results.Any())
            {
                return "No relevant information found in the knowledge base.";
            }

            var formattedResults = results.Results
                .SelectMany(r => r.Partitions.Select(x => new { x, r.SourceUrl }))
                .Select(r => $"[Relevance: {r.x.Relevance}] {r.x.Text}")
                .ToArray();

            return string.Join("\n\n", formattedResults);
        }
        catch (Exception ex)
        {
            return $"Error searching memory: {ex.Message}";
        }
    }

    [KernelFunction("Ask")]
    [Description("Ask a question and get an AI-generated answer based on the knowledge base")]
    public async Task<string> AskAsync(
        [Description("The question to ask")] string question,
        [Description("Minimum relevance score for sources")] double minRelevance = 0.7)
    {
        try
        {
            var answer = await _memoryClient.AskAsync(question, minRelevance: minRelevance);
            return answer.Result;
        }
        catch (Exception ex)
        {
            return $"Error asking question: {ex.Message}";
        }
    }
}