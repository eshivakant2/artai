﻿using Microsoft.SemanticKernel;
using Microsoft.SemanticKernel.ChatCompletion;
using System.ComponentModel;

public class ConversationHistoryPlugin
{
    private readonly ChatHistory _chatHistory;
    public ConversationHistoryPlugin(ChatHistory chatHistory)
    {
        _chatHistory = chatHistory;
    }

    [KernelFunction("GetRecentMessages")]
    [Description("Get recent messages from the conversation history")]
    public string GetRecentMessages(
        [Description("Number of recent message pairs to retrieve")] int count = 3)
    {
        var recentMessages = _chatHistory
            .Skip(Math.Max(1, _chatHistory.Count - (count * 2)))
            .Where(m => m.Role != AuthorRole.System)
            .Select(m => $"{(m.Role == AuthorRole.User ? "User" : "Assistant")}: {m.Content}")
            .ToArray();

        return recentMessages.Any() ? string.Join("\n", recentMessages) : "No recent conversation history.";
    }

    [KernelFunction("SearchHistory")]
    [Description("Search for specific topics in conversation history")]
    public string SearchHistory(
        [Description("Search term to look for in conversation history")] string searchTerm)
    {
        var matchingMessages = _chatHistory
            .Where(m => m.Role != AuthorRole.System &&
                       m.Content.ToString().Contains(searchTerm, StringComparison.OrdinalIgnoreCase))
            .Select(m => $"{(m.Role == AuthorRole.User ? "User" : "Assistant")}: {m.Content}")
            .ToArray();

        return matchingMessages.Any()
            ? string.Join("\n", matchingMessages)
            : $"No messages found containing '{searchTerm}'.";
    }

    [KernelFunction("GetMessageCount")]
    [Description("Get the total number of messages in the conversation")]
    public string GetMessageCount()
    {
        var userMessages = _chatHistory.Count(m => m.Role != AuthorRole.System);
        return $"Total conversation messages: {userMessages}";
    }
}
