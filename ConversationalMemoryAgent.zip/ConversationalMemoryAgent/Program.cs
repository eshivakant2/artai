﻿using Microsoft.SemanticKernel.Connectors.OpenAI;
using Microsoft.KernelMemory;

class Program
{
    static async Task Main(string[] args)
    {
        // Configure connection to Kernel Memory service
        var memoryClient = new MemoryWebClient("http://localhost:9001");

        // Create conversation manager
        var conversationManager = new ConversationManager(memoryClient);

        // Start interactive chat
        await conversationManager.StartChatAsync();
    }
}
