﻿using Microsoft.SemanticKernel;
using Microsoft.SemanticKernel.ChatCompletion;
using Microsoft.KernelMemory;
using System.Text.Json;

public class ConversationManager
{
    private readonly IKernelMemory _memoryClient;
    private readonly Kernel _kernel;
    private readonly IChatCompletionService _chatService;
    private readonly ChatHistory _chatHistory;
    private readonly string _conversationId;

    private string apiKey = Environment.GetEnvironmentVariable("OPENAI_API_KEY") ?? "";
    const string modelName = "gpt-4.1-nano-2025-04-14";


    public ConversationManager(IKernelMemory memoryClient)
    {
        _memoryClient = memoryClient;
        _conversationId = Guid.NewGuid().ToString();
        _chatHistory = new ChatHistory();

        // Configure Semantic Kernel with OpenAI
        _kernel = CreateKernelWithMemory();
        _chatService = _kernel.GetRequiredService<IChatCompletionService>();

        // Initialize with system message
        InitializeChatHistory();
    }

    private Kernel CreateKernelWithMemory()
    {
        var openAiApiKey = apiKey;

        if (string.IsNullOrEmpty(openAiApiKey))
        {
            throw new InvalidOperationException("OPENAI_API_KEY environment variable is required");
        }

        var kernelBuilder = Kernel.CreateBuilder()
            .AddOpenAIChatCompletion(
                modelId: modelName,
                apiKey: openAiApiKey);

        // Add memory plugin
        kernelBuilder.Plugins.AddFromObject(
            new KernelMemoryServicePlugin(_memoryClient),
            "Memory");

        // Add conversation history plugin
        kernelBuilder.Plugins.AddFromObject(
            new ConversationHistoryPlugin(_chatHistory),
            "History");

        return kernelBuilder.Build();
    }

    private void InitializeChatHistory()
    {
        var systemMessage = """
            You are a helpful AI assistant with access to a knowledge base and conversation history.
            
            Guidelines:
            1. Use the Memory.Search function to find relevant information from the knowledge base when needed
            2. Refer to previous parts of our conversation when relevant using the History functions
            3. Be conversational and remember what we've discussed
            4. If asked about something we discussed earlier, reference the conversation history
            5. Provide clear, helpful responses based on both the knowledge base and our chat history
            """;

        _chatHistory.AddSystemMessage(systemMessage);
    }

    public async Task StartChatAsync()
    {
        Console.WriteLine("=== AI Assistant with Memory and Conversation History ===");
        Console.WriteLine("Type 'exit' to quit, 'history' to see conversation, 'clear' to clear history");
        Console.WriteLine("Type 'import' to add text to knowledge base");
        Console.WriteLine();

        while (true)
        {
            Console.Write("You: ");
            var userInput = Console.ReadLine();

            if (string.IsNullOrWhiteSpace(userInput))
                continue;

            if (userInput.ToLower() == "exit")
                break;

            if (userInput.ToLower() == "history")
            {
                ShowConversationHistory();
                continue;
            }

            if (userInput.ToLower() == "clear")
            {
                ClearHistory();
                continue;
            }

            if (userInput.ToLower() == "import")
            {
                await HandleImportCommand();
                continue;
            }

            await ProcessUserMessageAsync(userInput);
        }

        // Optionally save conversation history
        await SaveConversationHistoryAsync();
    }

    private async Task ProcessUserMessageAsync(string userInput)
    {
        try
        {
            // Add user message to history
            _chatHistory.AddUserMessage(userInput);

            // Create enhanced prompt that can use both memory and history
            var enhancedPrompt = await CreateEnhancedPromptAsync(userInput);

            // Get response using chat completion with history
            var response = await GetChatResponseAsync(enhancedPrompt);

            // Add assistant response to history
            _chatHistory.AddAssistantMessage(response);

            Console.WriteLine($"Assistant: {response}");
            Console.WriteLine();
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error: {ex.Message}");
            Console.WriteLine();
        }
    }

    private async Task<string> CreateEnhancedPromptAsync(string userInput)
    {
        // Search knowledge base for relevant information
        var memoryResults = await _memoryClient.SearchAsync(userInput, limit: -1, minRelevance: 0.5);

        var knowledgeContext = "";
        if (memoryResults.Results.Any())
        {
            var relevantInfo = memoryResults.Results
                .SelectMany(r => r.Partitions.Select(x => new { x, r.SourceUrl }))
                .Select(r => $"[Relevance: {r.x.Relevance}] {r.x.Text}")
                .ToArray();
            knowledgeContext = $"\nRelevant information from knowledge base:\n{string.Join("\n", relevantInfo)}\n";
        }

        // Get recent conversation context (last 5 exchanges)
        var recentHistory = GetRecentConversationContext(5);

        var enhancedPrompt = $"""
            {knowledgeContext}
            
            Recent conversation context:
            {recentHistory}
            
            Current user message: {userInput}
            
            Please respond naturally, incorporating relevant information from both the knowledge base and our conversation history.
            """;

        return enhancedPrompt;
    }

    private async Task<string> GetChatResponseAsync(string prompt)
    {
        // Create a temporary chat history for this specific request
        var tempHistory = new ChatHistory();
        tempHistory.AddSystemMessage(_chatHistory[0].Content.ToString()); // System message

        // Add recent conversation context
        var recentMessages = _chatHistory.Skip(Math.Max(0, _chatHistory.Count - 10)).ToList();
        foreach (var message in recentMessages.Skip(1)) // Skip system message
        {
            if (message.Role == AuthorRole.User)
                tempHistory.AddUserMessage(message.Content.ToString());
            else if (message.Role == AuthorRole.Assistant)
                tempHistory.AddAssistantMessage(message.Content.ToString());
        }

        // Add current enhanced prompt
        tempHistory.AddUserMessage(prompt);

        var response = await _chatService.GetChatMessageContentAsync(tempHistory);
        return response.Content;
    }

    private string GetRecentConversationContext(int messageCount)
    {
        var recentMessages = _chatHistory
            .Skip(Math.Max(1, _chatHistory.Count - (messageCount * 2))) // Skip system message, get user/assistant pairs
            .Where(m => m.Role != AuthorRole.System)
            .Select(m => $"{(m.Role == AuthorRole.User ? "User" : "Assistant")}: {m.Content}")
            .ToArray();

        return recentMessages.Any() ? string.Join("\n", recentMessages) : "No recent conversation history.";
    }

    private void ShowConversationHistory()
    {
        Console.WriteLine("\n=== Conversation History ===");

        var userMessages = _chatHistory.Where(m => m.Role != AuthorRole.System).ToList();

        if (!userMessages.Any())
        {
            Console.WriteLine("No conversation history yet.");
        }
        else
        {
            foreach (var message in userMessages)
            {
                var role = message.Role == AuthorRole.User ? "You" : "Assistant";
                var content = message.Content?.ToString() ?? "";

                // Truncate long messages for display
                if (content.Length > 200)
                    content = content.Substring(0, 200) + "...";

                Console.WriteLine($"{role}: {content}");
            }
        }

        Console.WriteLine($"\nTotal messages: {userMessages.Count}");
        Console.WriteLine("========================\n");
    }

    private void ClearHistory()
    {
        // Keep only the system message
        var systemMessage = _chatHistory[0];
        _chatHistory.Clear();
        _chatHistory.Add(systemMessage);

        Console.WriteLine("Conversation history cleared.\n");
    }

    private async Task HandleImportCommand()
    {
        Console.Write("Enter text to import into knowledge base: ");
        var text = Console.ReadLine();

        if (!string.IsNullOrWhiteSpace(text))
        {
            var documentId = $"user-import-{DateTime.UtcNow:yyyyMMdd-HHmmss}";
            await _memoryClient.ImportTextAsync(text, documentId: documentId);
            Console.WriteLine($"Text imported with ID: {documentId}\n");
        }
    }

    private async Task SaveConversationHistoryAsync()
    {
        try
        {
            var historyData = new
            {
                ConversationId = _conversationId,
                Timestamp = DateTime.UtcNow,
                Messages = _chatHistory.Skip(1).Select(m => new // Skip system message
                {
                    Role = m.Role.ToString(),
                    Content = m.Content?.ToString(),
                    Timestamp = DateTime.UtcNow
                }).ToList()
            };

            var json = JsonSerializer.Serialize(historyData, new JsonSerializerOptions { WriteIndented = true });
            var fileName = $"conversation-{_conversationId}.json";

            await File.WriteAllTextAsync(fileName, json);
            Console.WriteLine($"Conversation history saved to: {fileName}");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Failed to save conversation history: {ex.Message}");
        }
    }
}
